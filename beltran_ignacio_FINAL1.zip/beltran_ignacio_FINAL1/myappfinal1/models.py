from django.db import models

# Create your models here.
class inscritos(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=80, default="")
    telefono = models.IntegerField(default=0)
    fechai = models.DateField()#fecha de reserva
    horai = models.TimeField()
    institucion = models.IntegerField(default="Sin Institucion")
    estado = models.CharField(max_length=80, null=True, blank=True)
    observacion = models.CharField(max_length=130)

class institucion(models.Model):
    id = models.AutoField(primary_key=True)    
    nombre = models.CharField(max_length=80)