#serializers.py   para usarlo hay q importar:::

from rest_framework import serializers
from .models import institucion

class InstSeria(serializers.ModelSerializer):
    class Meta:
        model = institucion
        fields = '__all__'
        