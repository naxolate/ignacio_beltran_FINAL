from django import forms
from django.core import validators
from . import models


     
class FormInscritos(forms.ModelForm):
        class Meta:
            model = models.inscritos
            fields = '__all__'        
        ESTADOS  = (
            ('Seleccione estado', 
                (('reservado', 'RESERVADO'),
                ('completada', 'COMPLETADA'),
                ('anulada', 'ANULADA'),
                ('no asisten', 'NO ASISTEN'))
            ),)
        
        i = (
            ('Seleccione institucion', 
                (('1', 'Coca cola'),
                ('2', 'Pepsi'),
                ('3', 'Kryspo'),
                ('4', 'Pringles'))
            ),)
            #[('seleccionar', 'SELECCIONAR'), ('reservado', 'RESERVADO'), ('completada', 'COMPLETADA'), ('anulada', 'ANULADA'), ('no asisten', 'NO ASISTEN')]
        nombre = forms.CharField(validators=[validators.MinLengthValidator(3), validators.MaxLengthValidator(20)])
        institucion = forms.CharField(widget=forms.Select(choices=i))
        telefono = forms.IntegerField()
        fechai = forms.DateField()#fecha de reserva                                                                                                                                                                                                                                                                                                                                                                                     
        horai = forms.TimeField()
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
        estado = forms.CharField(widget=forms.Select(choices=ESTADOS))
        observacion = forms.CharField() #require=False


