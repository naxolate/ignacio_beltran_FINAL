from django.shortcuts import render, redirect
from .models import inscritos, institucion
from . import forms
from .serializers import InstSeria
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view

from rest_framework.views import APIView
from django.http import Http404
# Create your views here.
class InstitucionList_class(APIView):
    def get(self, request):
        institu = institucion.objects.all()
        serial = InstSeria(institu, many=True)
        return Response(serial.data)
    
    def post(self, request):
        serial = InstSeria(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data, status=status.HTTP_201_CREATED)
        return Response(serial.errors, status=status.HTTP_400_BAD_REQUEST)


class Institucion_detalle_class(APIView):
    def get_object(self, id):
        try:
            return institucion.objects.get(pk=id)
        except institucion.DoesNotExist:
            return Http404

    def get(self, request, id):
        instit = self.get_object(id)
        serial = InstSeria(instit)
        return Response(serial.data)

    def put(self, request, id):
        instit = self.get_object(id)
        serial = InstSeria(instit, data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
        return Response(serial.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def delete(self, request, id):
        instit = self.get_object(id)
        instit.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    

@api_view(['GET', 'POST'])
def institucion_list(request):
    if request.method == 'GET':
        institu = institucion.objects.all()
        serial =InstSeria(institu, many=True)
        return Response(serial.data)
    
    if request.method == 'POST':
        serial = InstSeria(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data, status=status.HTTP_201_CREATED)
        return Response(serial.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'PUT', 'DELETE'])
def institucion_detalle(request, id):
    try:
        institu = institucion.objects.get(pk=id)
    except institucion.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)
    
    if request.method == 'GET':
        serial = InstSeria(institu)
        return Response(serial.data)
    
    if request.method == 'PUT':
        serial = InstSeria(institu, data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
        return Response(serial.errors, status=status.HTTP_400_BAD_REQUEST)
    
    if request.method == 'DELETE':
        institu.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)



    
def index(request):
    return render(request, 'index.html')

def listaInscritos(request):
    rese = inscritos.objects.all()##basicamente hacer un SELECT * FROM inscritos
    data = {'res': rese}
    return render(request,'inscritos.html', data)

def registrar_inscrito(request):
    form = forms.FormInscritos()
    if (request.method == 'POST'):
        form = forms.FormInscritos(request.POST)
        if (form.is_valid()):
            form.save()
    data = {'form': form}
    return render(request, 'agregar.html', data)

